#include <stdio.h>
#include "../threads/thread.h"

int main(int argc, const char* argv[]){
    printf("Hello world");
}

void print_thread(thread *t){
    printf("\n");
    printf("p:%d", t->wakeUp);
    printf("\n");
} 
